//
//  ViewController.swift
//  MeChico
//
//  Created by 203a on 2022/06/10.
//

import UIKit

var images = [ "01.png", "03.png","02.png","04.png", "05.png", "06.png", "07.png"]

class ViewController: UIViewController {
    
    @IBOutlet var ImgView: UIImageView!
    @IBOutlet var pageControl: UIPageControl!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        pageControl.numberOfPages = images.count
        
        pageControl.currentPage = 0
        
        pageControl.pageIndicatorTintColor = UIColor.gray
        
        pageControl.currentPageIndicatorTintColor = UIColor.red
        
        ImgView.image = UIImage(named: images[0])
        
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func pageChange(_ sender: UIPageControl) {
        ImgView.image = UIImage(named: images[pageControl.currentPage])
    }
   
    @IBAction func UIbtn(_ sender: UIButton) {
        let dialog = UIAlertController(title: "죄송합니다.", message: "준비중입니다.", preferredStyle: .alert)
        let action = UIAlertAction(title: "확인", style: UIAlertAction.Style.default)
                                    dialog.addAction(action)
                                    self.present(dialog, animated: true, completion: nil)
        
    }
    @IBAction func btnMoveImageView(_ sender: UIButton) {
        tabBarController?.selectedIndex = 3    }
    
}

